#include "Race.h"
#include "Utilizer.h"

/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE 
*/

Race::Race(std::string race_name){
	this->head = NULL;
	this->race_name = race_name;
	//average_laptime=Utilizer::generateAverageLaptime();
	//average_laptime.setLaptime(34535);
	

}
    Race::Race(const Race& rhs){};

    Race::~Race(){};


Car* Race::getHead(){
    //return this->head;
}