package hw1;

public class ClearVarsVisitor implements MathVisitor<Void> {

	@Override
	public Void visit(Op op) {
		// TODO Auto-generated method stub
		ClearVarsVisitor visitor = new ClearVarsVisitor();
		op.getFirst().accept(visitor);
		op.getSecond().accept(visitor);
		return null;
	}

	@Override
	public Void visit(Num num) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Void visit(Sym sym) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Void visit(Var var) {
		// TODO Auto-generated method stub
		var.setPreviousMatch(null);
		return null;
	}

}
