package hw1;

public class CountAtomicsVisitor implements MathVisitor<Integer> {
	// kullanimi su sekilde: op.accept(new countatomicsvisitor())
	// op bir mathexpression. icindeki atomics sayisini donecek.
	// accept in icinde visit cagriliyor.
	// yani burada her objenin visit'ini tanimlasak yeter.
	
	// bu design patternin benim icin kolayligi :
	// her classaa bir fonksiyon yazacaktin 
	// her classin ici biraz karisik olacakti
	// onun yerine visitor'un icinde dolduruyosun.
	// ayni fonksiyonlar bi yerde toplanmis oluyor.
	// baska patternler de kullanilabilir bence.
	
	
	
	public Integer visit(Op op) {
		//CountAtomicsVisitor visitor = new CountAtomicsVisitor();
		//no need to create instance
		return op.getFirst().accept(this) + op.getSecond().accept(this);
		
	}
	public Integer visit(Sym sym) {
		return 1;
	}
	public Integer visit(Var var) {
		return 1;
	}
	public Integer visit(Num num) {
		return 1;
	}
}
