package hw1;

import java.util.ArrayList;

public class Document implements DocElement {
	
	private String title;
	private ArrayList<DocElement> elements = new ArrayList<DocElement>();
	
	public Document(String title) {
		this.title = title;
	}
	
	public ArrayList<DocElement> getElements(){
		return elements;
	}
	
	public void setElements(ArrayList<DocElement> arr) {
		this.elements = arr;
	}
	
	public void add(DocElement de) {
		this.elements.add(de);
	}
	
	@Override
	public <T> T accept(TextVisitor<T> visitor) {
		return visitor.visit(this);
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
}
