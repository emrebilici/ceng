package hw1;

public class Main3 {

    public static void main(String[] args) {

        Document document = new Document("test3");
        Sym x = new Sym("x");

        Op r = new Op("/",new Num(1),new Num(0));
        Op r2 = new Op("/",new Num(1),new Num(0));

        Op matches1 = new Op("+",r,r2);
        document.add(new Paragraph("matches1"));
        document.add(new EquationText(matches1));

        Op matches2 = new Op("+",x,x);
        document.add(new Paragraph("matches2"));
        document.add(new EquationText(matches2));

        Op doesntmatch = new Op("+",x,r);
        document.add(new Paragraph("doesntmatch"));
        document.add(new EquationText(doesntmatch));
        
        Num eslenmez = new Num(5);

        XPlusXIs2XRule rule = new XPlusXIs2XRule(new Var(8));
        document.add(new Paragraph("rule, newly created"));
        document.add(new Paragraph((new EquationText(new Op("|-",rule.getPremise(),rule.getEntails()))).accept(new PrintHTMLVisitor())));

        document.add(new Paragraph("Try applying it to matches1, the rule is cleared, if it 'doesn't match', it should stay clear"));
        rule.apply(matches1);
        document.add(new Paragraph((new EquationText(new Op("|-",rule.getPremise(),rule.getEntails()))).accept(new PrintHTMLVisitor())));

        document.add(new Paragraph("Try applying it to matches2, the rule is cleared, if it 'doesn't match', it should stay clear"));
        rule.apply(matches2);
        document.add(new Paragraph((new EquationText(new Op("|-",rule.getPremise(),rule.getEntails()))).accept(new PrintHTMLVisitor())));

        document.add(new Paragraph("Try applying it to doesntmatch, the rule is cleared, if it 'doesn't match', it should stay clear"));
        rule.apply(doesntmatch);
        document.add(new Paragraph((new EquationText(new Op("|-",rule.getPremise(),rule.getEntails()))).accept(new PrintHTMLVisitor())));

        document.add(new Paragraph("Tip hatalari:"));
        rule.apply(eslenmez);
        document.add(new Paragraph((new EquationText(new Op("|-",rule.getPremise(),rule.getEntails()))).accept(new PrintHTMLVisitor())));



        System.out.print(document.accept(new PrintHTMLVisitor()));





    }
}
