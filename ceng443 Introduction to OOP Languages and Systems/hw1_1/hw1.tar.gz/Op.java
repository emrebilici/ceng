package hw1;

public class Op implements MathExpression{
	
	private String operand;
	private MathExpression first;
	private MathExpression second;
	
	public Op(String operand, MathExpression first, MathExpression second ) {
		this.operand = operand;
		this.first = first;
		this.second = second;
	}
	
	public String getOperand() {
		return operand;
	}
	
	public MathExpression getFirst() {
		return first;
	}
	
	public MathExpression getSecond() {
		return second;
	}
	
	@Override
	public <T> T accept(MathVisitor<T> visitor){
		return visitor.visit(this);
	}

	@Override
	public boolean match(MathExpression me) {
		// yanlis olabilirrrr!!!!!!!!!!!!!!!!!!!!!!!!!
		// burada recursive olmali ki var da isler kolaylassin
		// TODO else in icini operandlari kontrol et.
		if(me instanceof Num || me instanceof Sym) {
			return false;
		}
		else {
			if (((Op) me).getOperand() == this.getOperand()) {
				return this.getFirst().match(((Op) me).getFirst()) && this.getSecond().match(((Op) me).getSecond()); 
			}
			else {
				return false;
			}
				
		}
	}
	

}
