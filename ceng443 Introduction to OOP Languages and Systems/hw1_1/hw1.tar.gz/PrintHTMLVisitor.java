package hw1;

import java.util.ArrayList;

public class PrintHTMLVisitor implements TextVisitor<String> {
	//TODO buralari doldur. once equationtexti falan yap.
	// orada mathml i kullancan muhtemelen.
	// mathml ne guzel string donuyor.
	//
	// her mathexpressionin accept diye methodu var
	// bu method visitorun uygulanmasini sagliyor.
	// yani bir fonksiyonu(visitor) cagiracaksan visitorunu olustur burada.
	// sonra istedigin obje nin accept methoduna argument olarak ver.
	// => num.accept(visitor)
	// accept de zaten visitorun visitini cagiriyo
	
	
	@Override
	public String visit(Document document) {
		String title = document.getTitle();
		ArrayList<DocElement> elements = document.getElements();
		
		PrintHTMLVisitor visitor = new PrintHTMLVisitor();
		
		String printing = "<html><head><title>" + title + "</title></head><body>";
		for(DocElement i: elements) {
			String concat = i.accept(visitor);
			printing += concat;
		} ;
		printing.concat("</body></html>");
		return printing;
	}

	@Override
	public String visit(EquationText equationText) {
		PrintMathMLVisitor visitor = new PrintMathMLVisitor();
		
		return "<math>" + equationText.getInnerMath().accept(visitor) + "</math>" ;
	}

	@Override
	public String visit(Paragraph paragraph) {
		return "<p>" + paragraph.getText() + "</p>";
	}

}
