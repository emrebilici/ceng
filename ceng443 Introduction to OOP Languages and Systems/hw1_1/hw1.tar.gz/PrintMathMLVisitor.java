package hw1;

public class PrintMathMLVisitor implements MathVisitor<String> {
	//TODO: burada da nested mathexpression var.
	
	
	@Override
	public String visit(Op op) {
		PrintMathMLVisitor visitor = new PrintMathMLVisitor();
		if(op.getOperand()=="/") {
			return "<mrow><mfrac>" + op.getFirst().accept(visitor) + 
					"" + op.getSecond().accept(visitor) + "</mfrac></mrow>"; 
		}
		else if(op.getOperand()=="+"){
			return "<mrow><mo>(</mo>"+ op.getFirst().accept(visitor) +"<mo>" + "+" 
				+ "</mo>" + op.getSecond().accept(visitor) + "<mo>)</mo></mrow>";
		}
		else if(op.getOperand()=="*"){
			return "<mrow><mo>(</mo>"+ op.getFirst().accept(visitor) +"<mo>" + "&times;" 
				+ "</mo>" + op.getSecond().accept(visitor) + "<mo>)</mo></mrow>";
		}
		else if(op.getOperand()=="|-"){
			return "<mrow><mo>(</mo>"+ op.getFirst().accept(visitor) +"<mo>" + "&vdash;" 
				+ "</mo>" + op.getSecond().accept(visitor) + "<mo>)</mo></mrow>";
		}
		else {
			return "";
		}
	}

	@Override
	public String visit(Num num) {
		return "<mrow><mn>" + num.getValue() + "</mn></mrow>";
	}

	@Override
	public String visit(Sym sym) {
		return "<mrow><mi>" + sym.getValue() + "</mi></mrow>";
	}

	@Override
	public String visit(Var var) {
		
		//TODO: how can we print nested mathexpression.
		// yanlis olabilir: var.getPreviousMatch().accept(visitor) 
		// direkt var.accept yazman gerekebilir.
	
		PrintMathMLVisitor visitor = new PrintMathMLVisitor();	
	
		if(var.getPreviousMatch()!= null) {
			return "<mrow><msub><mi>" + "V" + "</mi><mn>" + var.getId() + 
					"</mn></msub><mo>[</mo>" + var.getPreviousMatch().accept(visitor) + "<mo>]</mo></mrow>" ; 
	
		}
		else {
			return "<mrow><msub><mi>V</mi><mn>" + var.getId() + 
					"</mn></msub></mrow>";
		}
		
		
	}

}
