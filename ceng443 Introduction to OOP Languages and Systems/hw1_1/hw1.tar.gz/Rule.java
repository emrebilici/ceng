package hw1;

public interface Rule {
	public default void clear() {
		ClearVarsVisitor visitor = new ClearVarsVisitor();
		this.getPremise().accept(visitor);
		this.getEntails().accept(visitor);	
	}
	public boolean apply(MathExpression me);
	public MathExpression getPremise();
	public MathExpression getEntails();
	
	public default MathExpression entails(MathExpression me) {
		this.apply(me);
		return this.getEntails();
	}
	
}
