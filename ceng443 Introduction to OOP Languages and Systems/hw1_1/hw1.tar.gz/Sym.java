package hw1;

public class Sym implements MathExpression{
	
	private String value;
	
	public Sym(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}	
	
	@Override
	public <T> T accept(MathVisitor<T> visitor){
		return visitor.visit(this);
	}

	@Override
	public boolean match(MathExpression me) {
		// TODO Auto-generated method stub
		if (me instanceof Sym) {
			return (this.getValue() == ((Sym) me).getValue());
		}
		else {
			return false;
		}
		
	}


}
