package hw1;

public class Var implements MathExpression{
	
	private int id;
	private MathExpression previousMatch;
	
	public Var(int id) {
		this.id = id;
		this.previousMatch = null;
	}
	
	public int getId() {
		return id;
	}
	
	public MathExpression getPreviousMatch() {
		return previousMatch;
	}
	
	public void setPreviousMatch(MathExpression me) {
		this.previousMatch = me;
	}
	
	
	@Override
	public <T> T accept(MathVisitor<T> visitor){
		return visitor.visit(this);
	}

	@Override
	public boolean match(MathExpression me) {
		MathExpression pre = this.getPreviousMatch();
		if(pre==null) {
			this.setPreviousMatch(me);	//emin deilim
			return true;
		}
		else {
			// TODO burada v1 bir expression'a esitse. me ile kiyasla.
			// TODO var objesi varsa expressionin icinde ne yapicaz bilmiyorum
			// 2 var birbirine esit olabilir mi? su anlik olamaz seklinde yaptim
			
			// me ve pre numaraysa ayni sayi mi bak
			if((pre instanceof Num) && (me instanceof Num)) {
				return (((Num) pre).getValue() == ((Num) me).getValue());
			}
			// me ve pre sym
			else if ((pre instanceof Sym) && (me instanceof Sym)) {
				return (((Sym) pre).getValue() == ((Sym) me).getValue() );
			}
			// me ve pre op. burasi nested
			// eger prenin ilk elemani ile eslesirse ikinci elemana bak.
			// ilk eleman da op olursa onun da getfirst unu almak gerekiyorW
			else if ((pre instanceof Op) && (me instanceof Op)) {
				return pre.match(me);
			}
			
			// TODO var icin previousMatchler esit degil mi diye bakilabilir
			// onceden eslesmemisse dogru donuyo ama daha once eslesmisse bi kontrol et.
			// (V0 x V1) / V0  =  V1 
			// V0 in icinde previousmatch doluysa baska bir var geldiginde previousmatchleri karsilastirlmali sanirim
			// burasi bende kopuk biraz
			else if(me instanceof Var) {
				return pre.match(((Var) me).getPreviousMatch());
			}
			
			// eger pre ve me eslesmiyorsa yanlis don
			else { 
				return false;
			}
			
		}
		

	}
	
}
