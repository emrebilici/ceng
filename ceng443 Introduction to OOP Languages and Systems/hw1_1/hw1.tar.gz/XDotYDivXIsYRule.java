package hw1;

public class XDotYDivXIsYRule implements Rule {
	private Var x;
	private Var y;
	private MathExpression entail;
	private MathExpression premise;
	
	
	public XDotYDivXIsYRule(Var x, Var y) {
		this.x = x;
		this.y = y;
		this.premise = new Op("/", new Op("*",x, y), x);
		this.entail = y;
	}
	
	public Var getX() {
		return x;
	}
	
	public Var getY() {
		return y;
	}


	@Override
	public boolean apply(MathExpression me) {
		// TODO me op olmayabilir
		this.clear();
		

		if (premise.match(me)) {
			this.y.setPreviousMatch(((Op) ((Op) me).getFirst()).getSecond());
			this.entail = y;
			return true;
		}
		else {
			this.clear();
			return false;
		}
			

		
		
	}

	@Override
	public MathExpression getPremise() {	
		return premise;
	}

	@Override
	public MathExpression getEntails() {
		return entail;
	}

	
}
