package hw1;

public class XDotZeroIsZeroRule implements Rule {
	private Var x;
	private MathExpression entail;
	private MathExpression premise;
	
	public XDotZeroIsZeroRule(Var x) {
		this.x = x;
		this.premise = new Op("*", x, new Num(0));
		this.entail = new Num(0);
	}
	
	@Override
	public boolean apply(MathExpression me) {
		this.clear();
		if(this.premise.match(me)) {
			return true;
		}
		else {
			this.clear();
			return false;
		}		
	}

	@Override
	public MathExpression getPremise() {
		return this.premise;
	}

	@Override
	public MathExpression getEntails() {
		return this.entail;
	}

	public Var getX() {
		return x;
	}
	

}
