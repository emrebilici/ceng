package hw1;

public class XPlusXIs2XRule implements Rule {
	private Var x;
	private MathExpression entail;
	private MathExpression premise;
	
	public XPlusXIs2XRule(Var x) {
		this.x = x;
		this.premise = new Op("+", x, x);
		this.entail = new Op("*", new Num(2), x);
	}
	
	public Var getX() {
		return x;
	}
	
	@Override
	public boolean apply(MathExpression me) {
		// TODO Auto-generated method stub
		this.clear();

		if(this.premise.match(me)) {
			this.entail = new Op("*", new Num(2), this.getX() );
			return true;
		}
		else {
			this.clear();
			return false;
		}

	}

	@Override
	public MathExpression getPremise() {	
		return premise;
	}

	@Override
	public MathExpression getEntails() {
		return entail;
	}


}
